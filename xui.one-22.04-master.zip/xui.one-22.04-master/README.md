# xui.one
xui.one work ubuntu 22.04
for install

sudo wget https://raw.githubusercontent.com/ToastyToast25/xui.one/master/install.sh -O /root/install.sh && sudo bash /root/install.sh
